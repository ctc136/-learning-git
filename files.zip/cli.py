"""CLI commands using Typer."""

from typing import Optional

import typer
from rich.console import Console
from rich.prompt import IntPrompt, Prompt

from . import db
from .display import console, display_recipe, display_recipe_list
from .models import Ingredient, Recipe

app = typer.Typer(help="🍳 Recipe Manager — store, search, and organize your recipes.")


@app.command()
def add() -> None:
    """Add a new recipe interactively."""
    console.print("\n[bold green]➕ Add a New Recipe[/bold green]\n")

    name = Prompt.ask("Recipe name")
    prep_time = IntPrompt.ask("Prep time (minutes)")
    cook_time = IntPrompt.ask("Cook time (minutes)")
    servings = IntPrompt.ask("Servings")
    rating = IntPrompt.ask("Rating (1-5, 0 to skip)", default=0)
    if rating == 0:
        rating = None

    # Tags
    tags_input = Prompt.ask("Tags (comma-separated, e.g. quick,vegetarian)", default="")
    tags = [t.strip() for t in tags_input.split(",") if t.strip()]

    # Ingredients
    console.print("\n[bold]Ingredients[/bold] (enter a blank name to finish):")
    ingredients = []
    while True:
        ing_name = Prompt.ask("  Ingredient name", default="")
        if not ing_name:
            break
        ing_amount = Prompt.ask(f"  Amount for {ing_name}")
        ingredients.append(Ingredient(name=ing_name, amount=ing_amount))

    # Steps
    console.print("\n[bold]Steps[/bold] (enter a blank step to finish):")
    steps = []
    step_num = 1
    while True:
        step = Prompt.ask(f"  Step {step_num}", default="")
        if not step:
            break
        steps.append(step)
        step_num += 1

    recipe = Recipe(
        name=name,
        ingredients=ingredients,
        steps=steps,
        prep_time=prep_time,
        cook_time=cook_time,
        servings=servings,
        tags=tags,
        rating=rating,
    )

    conn = db.get_connection()
    try:
        db.add_recipe(conn, recipe)
        console.print(f"\n[bold green]✅ '{name}' saved![/bold green]\n")
    except Exception as e:
        console.print(f"\n[bold red]Error: {e}[/bold red]\n")
    finally:
        conn.close()


@app.command("list")
def list_recipes() -> None:
    """List all saved recipes."""
    conn = db.get_connection()
    recipes = db.get_all_recipes(conn)
    conn.close()
    display_recipe_list(recipes)


@app.command()
def view(name: str) -> None:
    """View a recipe in detail."""
    conn = db.get_connection()
    recipe = db.get_recipe_by_name(conn, name)
    conn.close()

    if recipe:
        display_recipe(recipe)
    else:
        console.print(f"[red]Recipe '{name}' not found.[/red]")


@app.command()
def search(
    ingredient: Optional[str] = typer.Option(None, "--ingredient", "-i", help="Search by ingredient"),
    tag: Optional[str] = typer.Option(None, "--tag", "-t", help="Filter by tag"),
    max_time: Optional[int] = typer.Option(None, "--max-time", "-m", help="Max total time in minutes"),
) -> None:
    """Search recipes by ingredient, tag, or time."""
    conn = db.get_connection()
    results = None

    if ingredient:
        results = db.search_by_ingredient(conn, ingredient)
        console.print(f"\n🔍 Recipes with [bold]{ingredient}[/bold]:\n")
    elif tag:
        results = db.search_by_tag(conn, tag)
        console.print(f"\n🏷  Recipes tagged [bold]{tag}[/bold]:\n")
    elif max_time:
        results = db.search_by_max_time(conn, max_time)
        console.print(f"\n⏱  Recipes under [bold]{max_time} minutes[/bold]:\n")
    else:
        console.print("[yellow]Provide at least one filter: --ingredient, --tag, or --max-time[/yellow]")
        conn.close()
        return

    conn.close()
    display_recipe_list(results)


@app.command()
def delete(name: str) -> None:
    """Delete a recipe by name."""
    confirm = Prompt.ask(f"Delete '{name}'? This can't be undone", choices=["y", "n"])
    if confirm != "y":
        console.print("Cancelled.")
        return

    conn = db.get_connection()
    deleted = db.delete_recipe(conn, name)
    conn.close()

    if deleted:
        console.print(f"[green]Deleted '{name}'.[/green]")
    else:
        console.print(f"[red]Recipe '{name}' not found.[/red]")


if __name__ == "__main__":
    app()


# Allow running as: python -m src.cli
def main():
    app()
